const cheerio = require('cheerio');
const axios = require('axios');
const request = require('request')
const jquery = require('jquery');
const { default: Axios } = require('axios');
var fs = require('fs');
var url = require('url')
const path = require('path')

//文件读取
//同步
var content = fs.readFileSync('hello.txt',{flag:'r',encoding:'utf-8'})

//异步封装
function fsRead(path){
  return new Promise((resolve, reject) => {
    fs.readFile(path,{flag:'r',encoding:'utf-8'},function(err,data){
      if(err){
        //执行失败
        reject(err)
      }else{
        resolve(data)
      }
    })
  });
}

async function ReadList (){
   let file1 = await fsRead('hello.txt')
   console.log(file1)
   let file2= await fsRead('hello copy.txt')
   console.log(file2)
}

ReadList()