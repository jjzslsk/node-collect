const cheerio = require('cheerio');
const axios = require('axios');
const request = require('request')
const { default: Axios } = require('axios');
const fs = require('fs');
const url = require('url')
const path = require('path')
const puppeteer = require('puppeteer');
const {requestGet,fsDir,fsWrite,fsRead,lcWait} = require('./tools')



async function getWeb (){

  const browser = await puppeteer.launch({headless:false})
  const page = await browser.newPage();

  //监听拦截 #threadlisttableid tbody tr no-b-border xst pagead2.googlesyndication.com  images.nvshenim.info luntanx18.info
  await  page.setRequestInterception(true)
  page.on('request',interceptedRequest=>{
    let urlObj = url.parse(interceptedRequest.url())  
    if(
      urlObj.hostname == 'jo2.host8.info' 
      || urlObj.hostname == 'google-analytics.com' 
      || urlObj.hostname == 'www.luntanx18.info' 
      || urlObj.hostname == 'pagead2.googlesyndication.com'
      || urlObj.hostname == 'googlesyndication.com'
      || urlObj.hostname == 'hn.inspectlet.com'
      || urlObj.hostname == 'images.nvshenim.info'
      || urlObj.hostname == 'images.ailra.space'
      || urlObj.hostname == 'luntanx18.info'
      || urlObj.hostname == 'www.qitian288.xyz'
      || urlObj.hostname == 'qitian288.xyz'
      || urlObj.hostname == 'images.duoduose.info'

      ){
      interceptedRequest.abort
    }else{
      interceptedRequest.continue()
    }
  })

    //超时处理
    await page.setDefaultNavigationTimeout(0);

    await page.goto('https://zhuboo.xyz/forum-159-1.html', {
    waitUntil: 'load',
        timeout: 0
    });
    page.$$eval('#threadlisttableid tbody tr th .xst',(element)=>{
      element.forEach(item=>{
        if(
        item.getAttribute('style') != 'font-weight: bold;color: #8F2A90;'
        //红粗字体
        && item.getAttribute('style') != 'font-weight: bold;color: #EE1B2E;' 
        && item.getAttribute('style') != 'font-weight: bold;'
        && item.getAttribute('style') != 'font-weight: bold;color: #3C9D40;'
        && item.getAttribute('style') != 'font-weight: bold;color: #2B65B7;'
        && item.getAttribute('style') != 'font-weight: bold;color: #EC1282;'
        && item.getAttribute('style') != 'color: #8F2A90;'
        && item.children.length != 1
        ){
          // console.log('https://zhuboo.xyz/'+ item.getAttribute('href'))
          let title = item.innerHTML
          console.log('innerH：',item.innerHTML)
          console.log('innerA：','https://zhuboo.xyz/'+ item.getAttribute('href'),item.innerHTML)
          const webSrcs = 'https://zhuboo.xyz/'+ item.getAttribute('href')
          
        }
      })
      // console.log('.xst')
    })


    // if(args[0]._text.slice(0,5) == 'zhubo'){
      //   fsWrite('haha.txt',`${args[0]._text.slice(8)}\n`)
      // }

      page.on('console',function(...args){
        if(args[0]._text.slice(0,6) == 'innerH'){
          // console.log(`${args[0]._text.slice(8)}`)
          let pathSrc = `${args[0]._text.slice(8).replace(",","，")}`
          pathSrc = pathSrc.replace("?","")
          fsDir('./dir/'+ pathSrc)
      }
      if(args[0]._text.slice(0,6) == 'innerA'){
        let urlKey = args[0]._text.slice(8).replace(",","，")
        // let indexKey = urlKey.indexOf("html")
        // let leftData = urlKey.substring(indexKey+4)
        // let rightData = urlKey.substring(0,indexKey+4)
        fsWrite('hello.txt',`${urlKey},`)
        // fsWrite('hello.txt',`{name:${leftData},url:${rightData}},`)

    }
      })

  console.log('执行完成')
}





//获取详情页数据----------------------------------------------------------------------------------------------------------------
//记步数
var getInfoImgNum = 0
async function getInfoImg(pagePath,filesSrc,newTxtUrlArr){
    const browser = await puppeteer.launch({headless:true})
    const page = await browser.newPage();

    //监听拦截 #threadlisttableid tbody tr no-b-border xst pagead2.googlesyndication.com  images.nvshenim.info luntanx18.info
  await  page.setRequestInterception(true)
  page.on('request',interceptedRequest=>{
    let urlObj = url.parse(interceptedRequest.url())  
    if(
      urlObj.hostname == 'jo2.host8.info' 
      || urlObj.hostname == 'google-analytics.com' 
      || urlObj.hostname == 'www.luntanx18.info' 
      || urlObj.hostname == 'pagead2.googlesyndication.com'
      || urlObj.hostname == 'googlesyndication.com'
      || urlObj.hostname == 'hn.inspectlet.com'
      || urlObj.hostname == 'images.nvshenim.info'
      || urlObj.hostname == 'images.ailra.space'
      || urlObj.hostname == 'luntanx18.info'
      || urlObj.hostname == 'www.qitian288.xyz'
      || urlObj.hostname == 'qitian288.xyz'
      || urlObj.hostname == 'images.duoduose.info'

      ){
      interceptedRequest.abort
    }else{
      interceptedRequest.continue()
    }
  })

  //超时参数
  page.goto(pagePath, {
    waitUntil: 'load',
    timeout: 0
  });

  page.on('console',function(...args){
    async function fnData (){
      if(args[0]._text.slice(0,6) == 'imgarr'){
          let arrRul = args[0]._text.slice(7).split(",")
          let dataImg = await getArrImg(arrRul,filesSrc)
          console.log(dataImg)
          let starts = await startFn()
          console.log(starts)
          process.exit()
      }
    }
    fnData()
  })

    //查找元素
    await page.waitForSelector('.pcb .t_fsz table img',{timeout:60000})

    let elementArrImg = await page.$$eval('.pcb ignore_js_op .zoom',(items)=>{
      let arrHref = []
      items.forEach(i=>{
        arrHref.push(i.getAttribute('file'))
      })
      console.log("imgarr:"+ arrHref)
    })



    async function getArrImg(imgs,filesSrc){
      return new Promise(function (resolve, reject) {
        let index = 0
          imgs.forEach(itemSrc => {
              let webPath = `dir/${filesSrc}/${url.parse(itemSrc).path}`
              let ws = fs.createWriteStream(webPath)
              console.log('发起请求')
              axios.get(itemSrc,{responseType:'stream'}).then(res=>{
                  res.data.pipe(ws)
                  console.log('加载中',index)
                  res.data.on('close',function(){
                      ws.close()
                      console.log('加载完成',index+1,"共："+imgs.length)
                      index++
                      if(imgs.length == index){
                        resolve('resolve加载完成：'+imgs.length+"张"+filesSrc)
                        browser.close();
                        return
                      }
                  })
              })
              .catch(err =>{
                console.log(err)
                // reject(err)
              })
          });
      });
    }
    

    async function startFn(){
      return new Promise((resolve, reject) => {
        if(newTxtUrlArr.length !== getInfoImgNum){
          getInfoImgNum++
          if(newTxtUrlArr.length == getInfoImgNum){
            resolve(`--------共${newTxtUrlArr.length}页,采集结束----------`)
            return
          }

          const indexKey1 = newTxtUrlArr[getInfoImgNum].indexOf("html")
          console.log('开始采集', getInfoImgNum+1 +"页",newTxtUrlArr[getInfoImgNum])
          getInfoImg(newTxtUrlArr[getInfoImgNum].substring(0,indexKey1+4),newTxtUrlArr[getInfoImgNum].substring(indexKey1+5),newTxtUrlArr)
        }
      });
    }
    
}




//读取文件
async function ReadList (){
  const file1 = await fsRead('hello.txt')
  const txtUrlArr = file1.split(",")
  let newTxtUrlArr = txtUrlArr.slice(0,-1)

  const indexKey = newTxtUrlArr[0].indexOf("html")
  // let leftData = newTxtUrlArr.substring(indexKey+4)
  // let rightData = newTxtUrlArr.substring(0,indexKey+4)
  getInfoImg(newTxtUrlArr[0].substring(0,indexKey+4),newTxtUrlArr[0].substring(indexKey+5),newTxtUrlArr)

}

//成文件夹和URL
// getWeb()
ReadList()