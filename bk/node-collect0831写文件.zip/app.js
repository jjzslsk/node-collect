const cheerio = require('cheerio');
const axios = require('axios');
const request = require('request')
const jquery = require('jquery');
const { default: Axios } = require('axios');
var fs = require('fs');
var url = require('url')
const path = require('path')

//文件写入
//同步
// var content = fs.writeFileSync('hello.txt','lslslsk11111111111',{flag:'w',encoding:'utf-8'})

//异步写入，覆盖
// fs.writeFile('hello.txt','88888',{flag:'w',encoding:'utf-8'},function(err){
//   if(err){
//     console.log('写入失败')
//   }else{
//     console.log('写入成功')
//   }
// })

//异步写入，追加 (换行)
function writeFs(path,content){
  return new Promise((resolve, reject) => {
    fs.writeFile(path,content,{flag:'a',encoding:'utf-8'},function(err,data){
      if(err){
        console.log('写入失败')
        reject(err)
      }else{
        console.log('写入成功')
        resolve(data)
      }
    })
  });
}

async function writeList (){
  await writeFs('hello.txt','你大爷\n')
  // await writeFs('hello.txt','呵呵\n')
}

writeList()