const cheerio = require('cheerio');
const axios = require('axios');
const request = require('request')
const jquery = require('jquery');
const { default: Axios } = require('axios');
var fs = require('fs');
var url = require('url')
const path = require('path')

// const webUrl = 'https://zhuboo.xyz/forum-159-1.html'
const webUrl = 'http://www.bbsnet.com/tag/yebidaxiong'

var config = {
  method: 'get',
  url: webUrl,
  headers: { 
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Safari/537.36',
    'Cookie': 'visid_incap_2101966=sgB7O2sGTvqv8Yzpfylp6kloSl8AAAAAQUIPAAAAAAAJfAb+UGzTVtBwPDVDKqZ7; incap_ses_531_2101966=XYoZTsXwGF1OFusbwH1eB0loSl8AAAAAftRs03RIWR3NLKWY7aPEbA==; nlbi_2101966=dlLLc7mi8H5ArdhvQA+ZPQAAAAAORQ7TqR5xjtEcE/4mGyr/'
  }
};

async function getImg(){
    await axios(config)
     .then(function (response) {
       console.log(response.data)
         var $ = cheerio.load(response.data)
         $('#post_container a').each((i,item)=>{
             let href = $(item).attr('href')
             let title = $(item).attr('title')
            //  let title = $(item).find('.title').text()
             parsePage(href,title)
         })
     })
     .catch(function (error) {
       console.log('失败')
     });

}

getImg()

 async function parsePage(imgUrl,title){
    let res  = await axios.get(imgUrl)
     let $ = cheerio.load(res.data)
     $('#post_content p img').each((i,item)=>{
         let src = $(item).attr('src')
        let extName = path.extname(`${src}`)
        let webPath = `img/${title}-${i}${extName}`
         let ws = fs.createWriteStream(webPath)
         axios.get(src,{responseType:'stream'}).then(res=>{
            res.data.pipe(ws)
            console.log('加载中',webPath)
            res.data.on('close',function(){
                ws.close()
                console.log('加载完成')
            })
         })
     })
}

