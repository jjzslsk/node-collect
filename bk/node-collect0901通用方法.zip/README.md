npm i puppeteer 无法安装

解决方案 npm install puppeteer@1.8.0 --unsafe-perm=true --allow-root

https://www.jianshu.com/p/a6dc715dc48c