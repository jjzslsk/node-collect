const cheerio = require('cheerio');
const axios = require('axios');
const request = require('request')
const { default: Axios } = require('axios');
var fs = require('fs');
var url = require('url')
const path = require('path')
const puppeteer = require('puppeteer');

async function getWeb (){

  const browser = await puppeteer.launch({headless:false})
  const page = await browser.newPage();

  //监听拦截 #threadlisttableid tbody tr no-b-border xst pagead2.googlesyndication.com  images.nvshenim.info luntanx18.info
  await  page.setRequestInterception(true)
  page.on('request',interceptedRequest=>{
    let urlObj = url.parse(interceptedRequest.url())  
    if(
      urlObj.hostname == 'jo2.host8.info' 
      || urlObj.hostname == 'google-analytics.com' 
      || urlObj.hostname == 'www.luntanx18.info' 
      || urlObj.hostname == 'pagead2.googlesyndication.com'
      || urlObj.hostname == 'googlesyndication.com'
      || urlObj.hostname == 'hn.inspectlet.com'
      || urlObj.hostname == 'images.nvshenim.info'
      || urlObj.hostname == 'images.ailra.space'
      || urlObj.hostname == 'luntanx18.info'
      || urlObj.hostname == 'www.qitian288.xyz'
      || urlObj.hostname == 'qitian288.xyz'
      || urlObj.hostname == 'images.duoduose.info'

      ){
      interceptedRequest.abort
    }else{
      interceptedRequest.continue()
    }
    console.log(urlObj)
  })

  // page.mainFrame()
  // .waitForSelector('#threadlisttableid ')
  // .then(() => console.log('First URL with image: ' + currentURL)); www.google-analytics.com

  await page.setDefaultNavigationTimeout(0);
  
  // await page.goto('http://www.bbsnet.com/tag/liwomeimei');

    await page.goto('https://zhuboo.xyz/forum-159-1.html', {
    waitUntil: 'load',
        timeout: 0
    });
    page.$$eval('#threadlisttableid tbody tr th .xst',(element)=>{
      element.forEach(item=>{
        if(
          item.getAttribute('style') != 'font-weight: bold;color: #EE1B2E;' 
        && item.getAttribute('style') != 'font-weight: bold;color: #8F2A90;'
        && item.getAttribute('style') != 'font-weight: bold;'
        && item.getAttribute('style') != 'font-weight: bold;color: #3C9D40;'
        && item.getAttribute('style') != 'font-weight: bold;color: #2B65B7;'
        && item.getAttribute('style') != 'font-weight: bold;color: #EC1282;'
        && item.getAttribute('style') != 'color: #8F2A90;'
        ){
          console.log('https://zhuboo.xyz/'+ item.getAttribute('href'))
        }
      })
      console.log('1111111111')

    })

  //获取详情页数据
//   await page.goto('https://zhuboo.xyz/thread-14195658-1-1.html', {
//     waitUntil: 'load',
//     timeout: 0
// });
// page.$$eval('td ignore_js_op .zoom',(element)=>{
//   element.forEach(item=>{
//     console.log(item.getAttribute('file'))
//   })
// })


  // const divsCounts = await page.$$eval('a',(element)=>{
  //   element.forEach(item=>{
  //     console.log(item.getAttribute('href'))
  //   })
  // })
  // await browser.close();
  console.log('执行完成')
}

getWeb()

