const cheerio = require('cheerio');
const axios = require('axios');
const request = require('request')
const { default: Axios } = require('axios');
var fs = require('fs');
var url = require('url')
const path = require('path')
const puppeteer = require('puppeteer');

async function getWeb (){

  // const browser = await puppeteer.launch({headless:false})
  // const page = await browser.newPage();

  //拦截
  // await  page.setRequestInterception(true)
  // page.on('request',interceptedRequest=>{
  //   let urlObj = url.parse(interceptedRequest.url())
  //   console.log(urlObj)
  // })

  
  // await page.goto('http://www.bbsnet.com/tag/liwomeimei'); https://zhuboo.xyz/forum-159-1.html

    // await page.goto('http://www.bbsnet.com/tag/liwomeimei', {
    // waitUntil: 'load',
    //     timeout: 0
    // });

    var currentURL = 'http://www.bbsnet.com/tag/liwomeimei';


    puppeteer.launch({headless:false}).then(async browser => {
      const page = await browser.newPage();
      await page.setDefaultNavigationTimeout(0);



      

      page.mainFrame()
        .waitForSelector('a')
        .then(() => console.log('First URL with image: ' + currentURL));

      await page.goto(currentURL);

      page.$$eval('#threadlisttableid tbody tr no-b-border xst',(element)=>{
        console.log('1111111111')
        // element.forEach(item=>{
        //   console.log(item.getAttribute('href'))
        // })
      })


    });







  //获取详情页数据
//   await page.goto('https://zhuboo.xyz/thread-14195658-1-1.html', {
//     waitUntil: 'load',
//     timeout: 0
// });
// page.$$eval('td ignore_js_op .zoom',(element)=>{
//   element.forEach(item=>{
//     console.log(item.getAttribute('file'))
//   })
// })


  // const divsCounts = await page.$$eval('a',(element)=>{
  //   element.forEach(item=>{
  //     console.log(item.getAttribute('href'))
  //   })
  // })
  // await browser.close();
  console.log('执行完成')
}

getWeb()

