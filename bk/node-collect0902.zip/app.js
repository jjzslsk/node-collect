const cheerio = require('cheerio');
const axios = require('axios');
const request = require('request')
const { default: Axios } = require('axios');
const fs = require('fs');
const url = require('url')
const path = require('path')
const puppeteer = require('puppeteer');
const {requestGet,fsDir,fsWrite,fsRead,lcWait} = require('./tools')



async function getWeb (){

  const browser = await puppeteer.launch({headless:false})
  const page = await browser.newPage();

  //监听拦截 #threadlisttableid tbody tr no-b-border xst pagead2.googlesyndication.com  images.nvshenim.info luntanx18.info
  await  page.setRequestInterception(true)
  page.on('request',interceptedRequest=>{
    let urlObj = url.parse(interceptedRequest.url())  
    if(
      urlObj.hostname == 'jo2.host8.info' 
      || urlObj.hostname == 'google-analytics.com' 
      || urlObj.hostname == 'www.luntanx18.info' 
      || urlObj.hostname == 'pagead2.googlesyndication.com'
      || urlObj.hostname == 'googlesyndication.com'
      || urlObj.hostname == 'hn.inspectlet.com'
      || urlObj.hostname == 'images.nvshenim.info'
      || urlObj.hostname == 'images.ailra.space'
      || urlObj.hostname == 'luntanx18.info'
      || urlObj.hostname == 'www.qitian288.xyz'
      || urlObj.hostname == 'qitian288.xyz'
      || urlObj.hostname == 'images.duoduose.info'

      ){
      interceptedRequest.abort
    }else{
      interceptedRequest.continue()
    }
  })

    //超时处理
    await page.setDefaultNavigationTimeout(0);

    await page.goto('https://zhuboo.xyz/forum-159-1.html', {
    waitUntil: 'load',
        timeout: 0
    });
    page.$$eval('#threadlisttableid tbody tr th .xst',(element)=>{
      element.forEach(item=>{
        if(
          item.getAttribute('style') != 'font-weight: bold;color: #EE1B2E;' 
        && item.getAttribute('style') != 'font-weight: bold;color: #8F2A90;'
        && item.getAttribute('style') != 'font-weight: bold;'
        && item.getAttribute('style') != 'font-weight: bold;color: #3C9D40;'
        && item.getAttribute('style') != 'font-weight: bold;color: #2B65B7;'
        && item.getAttribute('style') != 'font-weight: bold;color: #EC1282;'
        && item.getAttribute('style') != 'color: #8F2A90;'
        && item.children.length != 1
        ){
          // console.log('https://zhuboo.xyz/'+ item.getAttribute('href'))
          let title = item.innerHTML
          console.log('innerH：',item.innerHTML)
          console.log('innerA：','https://zhuboo.xyz/'+ item.getAttribute('href'),item.innerHTML)
          const webSrcs = 'https://zhuboo.xyz/'+ item.getAttribute('href')
          
        }
      })
      // console.log('.xst')
    })


    // if(args[0]._text.slice(0,5) == 'zhubo'){
      //   fsWrite('haha.txt',`${args[0]._text.slice(8)}\n`)
      // }

      page.on('console',function(...args){
        if(args[0]._text.slice(0,6) == 'innerH'){
          // console.log(`${args[0]._text.slice(8)}`)
          fsDir('./dir/'+ `${args[0]._text.slice(8).replace(",","，")}`)
      }
      if(args[0]._text.slice(0,6) == 'innerA'){
        let urlKey = args[0]._text.slice(8).replace(",","，")
        // let indexKey = urlKey.indexOf("html")
        // let leftData = urlKey.substring(indexKey+4)
        // let rightData = urlKey.substring(0,indexKey+4)
        fsWrite('hello.txt',`${urlKey},`)
        // fsWrite('hello.txt',`{name:${leftData},url:${rightData}},`)

    }
      })

  console.log('执行完成')
}





//获取详情页数据
async function getInfoImg(pagePath,filesSrc){

  console.log(pagePath)
  console.log(filesSrc)
  // return

    const browser = await puppeteer.launch({headless:false})
    const page = await browser.newPage();

    //监听拦截 #threadlisttableid tbody tr no-b-border xst pagead2.googlesyndication.com  images.nvshenim.info luntanx18.info
  await  page.setRequestInterception(true)
  page.on('request',interceptedRequest=>{
    let urlObj = url.parse(interceptedRequest.url())  
    if(
      urlObj.hostname == 'jo2.host8.info' 
      || urlObj.hostname == 'google-analytics.com' 
      || urlObj.hostname == 'www.luntanx18.info' 
      || urlObj.hostname == 'pagead2.googlesyndication.com'
      || urlObj.hostname == 'googlesyndication.com'
      || urlObj.hostname == 'hn.inspectlet.com'
      || urlObj.hostname == 'images.nvshenim.info'
      || urlObj.hostname == 'images.ailra.space'
      || urlObj.hostname == 'luntanx18.info'
      || urlObj.hostname == 'www.qitian288.xyz'
      || urlObj.hostname == 'qitian288.xyz'
      || urlObj.hostname == 'images.duoduose.info'

      ){
      interceptedRequest.abort
    }else{
      interceptedRequest.continue()
    }
  })

  page.goto(pagePath, {
    waitUntil: 'load',
    timeout: 0
    });


    page.on('console',function(...args){

      if(args[0]._text.slice(0,6) == 'zhuboo'){
          // fsWrite('haha.txt',`${args[0]._text.slice(8)}\n`)
          let imgUrl = args[0]._text.slice(8)
          //后缀名
          let extName = path.extname(`${imgUrl}`)

          //图片写入的路径和名字
          // let webPath = `img/${filesSrc}-${i}${extName}`
          // console.log(url.parse(imgUrl).path)

          let webPath = `dir/${filesSrc}/${url.parse(imgUrl).path}`
          let ws = fs.createWriteStream(webPath)
          axios.get(imgUrl,{responseType:'stream'}).then(res=>{
              res.data.pipe(ws)
              console.log('加载中',webPath)
              res.data.on('close',function(){
                  ws.close()
                  console.log('加载完成')
              })
          })

      }

    if(args[0]._text.slice(0,6) == 'dommmm'){
      console.log('下载完毕',args[0]._text)
      browser.close();
      // getInfoImg(file1.split(",")[1],files[1])
    }

    })


    //查找元素
    page
    .waitForSelector('ignore_js_op',{timeout: 120000})
    .then(() => {
      page.$$eval('td ignore_js_op .zoom',(element)=>{
        element.forEach(item=>{
          console.log('zhuboo：',item.getAttribute('file'))
        })
        console.log('dommmm：',element.length)
      })
    });




    
    
}




//读取文件
async function ReadList (){
  let file1 = await fsRead('hello.txt')
  let txtUrlArr = file1.split(",")
  txtUrlArr = txtUrlArr.slice(0,-1)
  txtUrlArr.forEach((element,index) => {
    
  });

  // fs.readdir('./dir', function(err,files){
  //   if(err){
  //     console.log('读取目录失败')
  //   }else{
  //     files.forEach((element,index) => {
  //       console.log(index,element)
  //     });
  //   }
  // })

  let indexKey = txtUrlArr[10].indexOf("html")
  // let leftData = txtUrlArr.substring(indexKey+4)
  // let rightData = txtUrlArr.substring(0,indexKey+4)
  // getInfoImg(txtUrlArr[10].substring(0,indexKey+4),txtUrlArr[10].substring(indexKey+5))

}

//成文件夹和URL
// getWeb()
ReadList()